
                               README.TXT file
                        for VEDA LPR demo application



        Contents:

        1. INTRODUCTION
        2. HOW TO INSTALL / UNINSTALL THE PROGRAMS
        3. HOW TO START / USE THE DEMO PROGRAM
        4. HOW TO TRAIN A (NEW) KNOWLEDGE BASE
        5. CONTACT



        1. INTRODUCTION

        VEDA LPR represents an almost completely new (Windows 32-bit)
Automatic License/Number Plate Recognition - AL(N)PR - software engine,
developed and implemented starting from our old VEDA CAR initial approach of
1993-94 (for DOS 16-bit). It is intended to optically localize and recognize
vehicles' license plates. This DEMO application uses as input color or
grayscale image files (grabbed/captured either by video cameras, or by digital
photo ones). It doesn't depend on a specific image acquisition board (frame
grabber). The supported image file formats include: JPEG, PNG, PCX, BMP, TIFF,
PGM and an old Imaging Technology 256 gray levels uncompressed IMG format. If
interfaced with some specific image acquisition chain (video camera, frame
grabber, triggering devices - photoelectric sensors / magnetic loops),
possible controller/actuator for access devices (gates / barriers) and a
database management system software application, the VEDA LPR engine can be
easily used for monitorizing, control and/or validate the access in restricted
areas, public and/or private parking lots or garages, to monitorize highway
(or other roads) traffic, red-light or speed limit infringements, to control
the in/out traffic at customs, toll collection points, to check vehicles
against "black"/"gray" lists (if stolen, unregistered, with certain mandatory
taxes / fees / insurance not paid) etc. VEDA LPR isn't directly meant as a
universal and ready-to-run solution, but merely as a foundation on which
customized ANPR/ALPR applications may be built. A simple to integrate Windows
32-bit SDK/API, providing the VEDA LPR engine's functions interface, is
available for developers / integrators (C/C++ header file, example C console
application - source and binary code, - DLL component libraries, other useful
stuff, etc.). A "fake" demo release of this SDK/API (for testing the VEDA LPR
engine's functions integration within applications) may be also downloaded for
free, from the respective page of the web site.



        2. HOW TO INSTALL / UNINSTALL THE PROGRAMS

        The DEMO package contains an INSTALL.BAT batch file, a self-extracting
archive INSTALL.EX_ file, a 3RD_PART.TXT text file containing acknowledgements
and license agreements for the third party libraries that are used, and this
README.TXT file (and, possibly, a RELNOTES.TXT one, with relevant release
notes) that would be recommended to be read before installing and start using
the computer programs provided in the package. A DECLHA.EX_ file extractor for
self-extracting LHA archives, from ponsoftware.com Japan (EXPLZH authors), is
also provided in the DEMO package for compatibility on 64-bit Windows systems.

        Create / choose a directory/folder on your hard-disk where you want to
install VEDA LPR demo application programs (e.g. one named: "C:\VEDALPR", or,
"C:\Program Files\VEDA\VEDALPR", or "C:\Program Files (x86)\VEDA\VEDALPR" on
Windows 64-bit machines etc.).

        Extract / copy the files contained by the DEMO package to this desired
directory / folder.

        Then, switch to the respective directory / folder, and proceed to the
installation by just running there the provided INSTALL.BAT batch file (that
will automatically control the extraction of the files from the self-
extracting archive INSTALL.EX_) according to the version of your Windows
operating system (x86/32-bit or x64/64-bit).

Note:

        No Windows registry alteration / modification is performed along the
installation process. Files are unpacked only in the respective directory /
folder if you didn't choose to put (some of) them in other location(s).


        If you want, you can delete / remove the self-extracting archive and
other installation-only required files (INSTALL.EX_, INSTALL.BAT, DECLHA.EXE)
from the respective directory / folder once the installation done.

        For uninstalling the VEDA LPR demo application, you simply have to
delete / remove all installed files, and the respective directory / folder,
from your disk.



        3. HOW TO START / USE THE DEMO PROGRAM

        From the directory / folder where you installed the DEMO, start the
VEDALPR.EXE program, and its main window opens. Use the [File(s)] button from
the upper controls bar to select the image file(s) to be analyzed. You can
either choose one, some, or even all the JPEG images you'll find in the DEMO
directory / folder, or, also any other (similar) image file(s) of your own
(in JPEG, PNG, PCX, BMP, TIFF, or IMG format). Also, you must select an OCR
knowledge base (e.g. the DEMO.KBF file that you'll also find in the above
mentioned directory) to be used for license plate(s) / number(s) recognition,
by using the [Kbase] button. If you chose a single image file, this one will
be directly analyzed (license plate will be located / segmented, binarized,
filtered, deskewed if necessary) and recognized. If you selected more than one
image file, "press" the [Start >>] / [Stop ||] button, or use the [|< Prev.]
or [Next >|] ones for analyzing the selected images one by one. In the former
case, each of the selected images will be automatically loaded, displayed,
analyzed and recognized, one after another. The delay between two consecutive
images (intended for observing the analysis and recognition results), can be
adjusted by using the slider from the controls bar. For stopping the automatic
run, just "press" the [Stop ||] button. The recognized license plate / number,
together with the system date and time, is shown in the bottom info bar for
each analyzed image, while the analysis duration can be seen in the upper
controls bar. From this latter one, you can also choose whether to have the
binarized-filtered-deskewed/deslanted bitmap of the license plate field
displayed, or not. It is recommended that you also read the brief help info
provided when using the [About...] button. For quitting the DEMO, use Alt+F4
or the upper-right "Close" button ([X]) of its main window.



        4. HOW TO TRAIN A (NEW) KNOWLEDGE BASE

        You can also use the VEDAPATT.EXE utility / tool for training new (yet
unknown) alphanumeric characters found in different images, or simply, just to
check out how a new knowledge base can be built up from scratch. In its main
window, firstly select the (new) OCR knowledge base you want to be trained.
Then, select the image(s) to be used. Start the analysis for locating the
license plate (i.e. the image segmentation) by using the [Seg.] button. If the
plate is found, a(n initially red) framing box / rectangle will show you it's
estimated location. If this one is ok., then just click over it (or "push" the
[Obj.#] button from the controls bar). The license plate red framing rectangle
becomes green, and a learning dialog box will be displayed. It shows the
binarized (and cleaned up) bitmap of the respective license plate. Firstly,
uncheck the upper-right [Only view...] option. A red framing rectangle will
appear, surrounding the first (yet) unknown license plate's character (if such
any). In those possible cases when the surrounding red framing rectangle
doesn't correctly bound a (single full) character, you may adjust its right
border by dragging it with the mouse or by using the left / right arrow keys
from the keyboard. Then, just type the respective character from the keyboard,
and then also type <Enter> twice for confirmation. Normally, the character has
to be thus learned. The red framing rectangle automatically "jumps" to the
next (yet) unknown character, if any. Repeat the above step until all the
(correctly framed) characters are thus learned, then "press" the [Done]
button. Repeat all the above steps (starting from the image file selection),
for as many other (new) images you want. Eventually, quit the pattern training
application by closing its main window by using the Alt+F4 combination from
your keyboard, or the upper-right "Close" button ([X]) of its main window. You
can then try the "strength" / quality of the (new) knowledge base you just
trained, by using it within the VEDALPR.EXE demo application, on the same
images that you used for training, and also on other ones (which case may
reveal that some more training sessions must be also performed)...



        5. CONTACT

        We'll always appreciate any feedback (impressions, questions,
suggestions, etc.) from you. Don't hesitate to contact us:

   Mr. Mihnea VREJOIU, e-mail: mvrejoiu@yahoo.com



Enjoy and success!
